var searchData=
[
  ['read_5faverage',['read_average',['../classadc.html#a78ce9328800df2bceb1cbc07f0270bb8',1,'adc']]],
  ['read_5fmedian',['read_median',['../classadc.html#a177ab41dc528c2beb60bcef17ee6f483',1,'adc']]],
  ['read_5fonce',['read_once',['../classadc.html#a2190a59696a7093e1ea605e998ccf97e',1,'adc']]],
  ['run',['run',['../classtask__adc.html#a3ef916a139b496f8edfd56fb89bbf555',1,'task_adc::run()'],['../classtask__master.html#aff6e03d8430ddfb412d1258c11d93f87',1,'task_master::run()'],['../classtask__motor.html#a895a075ec470c9d5a07b8959de06aacd',1,'task_motor::run()'],['../classtask__user.html#adca6429d57be25e8d411414fc8ad75af',1,'task_user::run()']]]
];
