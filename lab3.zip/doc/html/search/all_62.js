var searchData=
[
  ['bit_5ftwiddle_2ecpp',['bit_twiddle.cpp',['../bit__twiddle_8cpp.html',1,'']]],
  ['bit_5ftwiddle_2eh',['bit_twiddle.h',['../bit__twiddle_8h.html',1,'']]],
  ['brake',['brake',['../classmotor.html#abff6d2ccc592902ac6472d8078a897fa',1,'motor']]]
];
