var searchData=
[
  ['clear_5fand_5fset',['clear_and_set',['../bit__twiddle_8cpp.html#a28bba0b75bbf58ff168b8330ff19a9cc',1,'clear_and_set(volatile uint8_t &amp;reg, uint8_t bit):&#160;bit_twiddle.cpp'],['../bit__twiddle_8h.html#ad53d358644123e26b80792888448a4de',1,'clear_and_set(volatile uint8_t &amp;, uint8_t):&#160;bit_twiddle.cpp']]],
  ['compare',['compare',['../adc_8cpp.html#a67f19a23c6bb69d8c20f4f828a3d70e5',1,'compare(const void *num1, const void *num2):&#160;adc.cpp'],['../adc_8h.html#a7edc79f704d8f440f0b6e9b38a76085e',1,'compare(const void *, const void *):&#160;adc.cpp']]]
];
