var searchData=
[
  ['ticks_5fto_5fdelay',['ticks_to_delay',['../task__user_8cpp.html#a80f7a5c45b5679c45dd218506ab058f0',1,'task_user.cpp']]]
];
