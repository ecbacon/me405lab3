var searchData=
[
  ['set_5fbit',['set_bit',['../bit__twiddle_8cpp.html#a8f47afd328b9103ecea63326fa561f54',1,'set_bit(volatile uint8_t &amp;reg, uint8_t bit):&#160;bit_twiddle.cpp'],['../bit__twiddle_8h.html#a800eab4e9895cc2a79d637fc5ee33372',1,'set_bit(volatile uint8_t &amp;, uint8_t):&#160;bit_twiddle.cpp']]],
  ['set_5fpower',['set_power',['../classmotor.html#a168a159eebb68c7a47cd4153e03c030c',1,'motor']]],
  ['show_5fstatus',['show_status',['../classtask__user.html#a105bebbd9cb1031154c3dfc3662db4a0',1,'task_user']]]
];
