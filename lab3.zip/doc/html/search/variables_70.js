var searchData=
[
  ['ptr_5fto_5fserial',['ptr_to_serial',['../classadc.html#a14680b48b723bf1adddd2741ebb18a3e',1,'adc::ptr_to_serial()'],['../classmotor.html#a618a4f3836e6d7e204469f38a6036d6f',1,'motor::ptr_to_serial()']]]
];
