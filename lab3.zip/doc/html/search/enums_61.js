var searchData=
[
  ['adc_5fstate_5fenum',['adc_state_enum',['../shares_8h.html#a709454abeafb4f97052a3e005ba42f46',1,'shares.h']]]
];
