var searchData=
[
  ['print_5fhelp_5fmessage',['print_help_message',['../classtask__user.html#a75475060f83bae1e44bcc8a5c34015c7',1,'task_user']]],
  ['print_5fser_5fqueue',['print_ser_queue',['../lab__main_8cpp.html#a4c623cb3c8a60e67138367480c1ee0d2',1,'lab_main.cpp']]],
  ['program_5fversion',['PROGRAM_VERSION',['../task__user_8h.html#a2f10abd650e471fae2d7e8c63d41206a',1,'task_user.h']]],
  ['ptr_5fto_5fserial',['ptr_to_serial',['../classadc.html#a14680b48b723bf1adddd2741ebb18a3e',1,'adc::ptr_to_serial()'],['../classmotor.html#a618a4f3836e6d7e204469f38a6036d6f',1,'motor::ptr_to_serial()']]]
];
